#!/usr/bin/env python3
"""
CrypQ - Secure Programming Language
Real UAV telemetry + BiLSTM temporal-attention threat detection.

Commands:
    setup-2fa
    run <file.cq>
    train-dl
    evaluate-dl
    demo

The ML subsystem is defensive: it detects/classifies telemetry anomalies
and maps predictions to verification/alert actions. It does not control
or engage any physical system.
"""

from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import argparse
import hashlib
import json
import os
import secrets
import sys
from pathlib import Path
from typing import Any, Callable

try:
    import pyotp
except ImportError:
    pyotp = None

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:
    AESGCM = None


PROJECT_DIR = Path(__file__).resolve().parent
DATA_FILE = PROJECT_DIR / "data" / "UAV Ground Telemetry Dataset.csv"
MODEL_DIR = PROJECT_DIR / "models" / "crypq_lstm"
TWO_FA_FILE = PROJECT_DIR / "crypq_2fa.json"


# ---------------------------------------------------------------------------
# 2FA
# ---------------------------------------------------------------------------

class TwoFactorAuth:
    def __init__(self, path: Path = TWO_FA_FILE) -> None:
        self.path = path

    def setup(self) -> None:
        if pyotp is None:
            raise RuntimeError("pyotp is not installed. Run: python3 -m pip install -r requirements.txt")

        secret = pyotp.random_base32()
        data = {"secret": secret}
        self.path.write_text(json.dumps(data, indent=2), encoding="utf-8")

        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

        uri = pyotp.TOTP(secret).provisioning_uri(
            name="CrypQ",
            issuer_name="CrypQ Quantum Project",
        )

        print("\n=== CRYPQ 2FA SETUP ===")
        print("Secret:", secret)
        print("Provisioning URI:", uri)
        print("Add the secret/URI to an authenticator app.")
        print("Then run: python3 crypq.py run examples/mission.cq\n")

    def authenticate(self) -> bool:
        if pyotp is None:
            raise RuntimeError("pyotp is not installed.")

        if not self.path.exists():
            print("[CRYPQ] 2FA is not configured.")
            print("Run: python3 crypq.py setup-2fa")
            return False

        data = json.loads(self.path.read_text(encoding="utf-8"))
        secret = data["secret"]
        totp = pyotp.TOTP(secret)

        for attempt in range(1, 4):
            code = input(f"Enter 2FA code (attempt {attempt}/3): ").strip()
            if totp.verify(code, valid_window=1):
                print("[CRYPQ] 2FA authentication successful.")
                return True

        print("[CRYPQ] 2FA authentication failed.")
        return False


# ---------------------------------------------------------------------------
# BB84-inspired simulation + AES-256-GCM
# ---------------------------------------------------------------------------

class BB84Simulator:
    def generate_key(self, bits: int = 2048, eavesdropper: bool = False) -> dict[str, Any]:
        if bits < 256:
            raise ValueError("bits must be at least 256.")

        alice_bits = [secrets.randbelow(2) for _ in range(bits)]
        alice_bases = [secrets.randbelow(2) for _ in range(bits)]
        bob_bases = [secrets.randbelow(2) for _ in range(bits)]

        bob_bits: list[int] = []
        for i in range(bits):
            measured = alice_bits[i]

            if eavesdropper:
                eve_basis = secrets.randbelow(2)
                if eve_basis != alice_bases[i]:
                    measured = secrets.randbelow(2)

            if bob_bases[i] != alice_bases[i]:
                measured = secrets.randbelow(2)

            bob_bits.append(measured)

        sifted = [
            alice_bits[i]
            for i in range(bits)
            if alice_bases[i] == bob_bases[i]
        ]
        bob_sifted = [
            bob_bits[i]
            for i in range(bits)
            if alice_bases[i] == bob_bases[i]
        ]

        errors = sum(a != b for a, b in zip(sifted, bob_sifted))
        qber = errors / max(1, len(sifted))

        # A real QKD system would perform error correction and privacy
        # amplification. This prototype hashes sifted material to 256 bits.
        if qber > 0.11:
            raise RuntimeError(f"QBER too high for accepted link: {qber:.3f}")

        if len(sifted) < 256:
            raise RuntimeError(
                f"Insufficient key material: {len(sifted)} sifted bits. "
                "Increase the BB84 round count."
            )

        packed = bytearray()
        for i in range(0, len(sifted) - 7, 8):
            value = 0
            for bit in sifted[i:i + 8]:
                value = (value << 1) | bit
            packed.append(value)

        key = hashlib.sha256(bytes(packed)).digest()

        return {
            "key": key,
            "rounds": bits,
            "sifted_bits": len(sifted),
            "qber": qber,
            "eavesdropper": eavesdropper,
        }


class SecureCrypto:
    def __init__(self, key: bytes) -> None:
        if AESGCM is None:
            raise RuntimeError(
                "cryptography is not installed. Run: "
                "python3 -m pip install -r requirements.txt"
            )
        if len(key) != 32:
            raise ValueError("AES-256 requires exactly 32 bytes.")
        self.aes = AESGCM(key)

    def encrypt(self, plaintext: str, aad: str = "CrypQ") -> dict[str, str]:
        nonce = secrets.token_bytes(12)
        ciphertext = self.aes.encrypt(
            nonce,
            plaintext.encode("utf-8"),
            aad.encode("utf-8"),
        )
        return {
            "nonce": nonce.hex(),
            "ciphertext": ciphertext.hex(),
            "aad": aad,
        }

    def decrypt(self, package: dict[str, str]) -> str:
        plaintext = self.aes.decrypt(
            bytes.fromhex(package["nonce"]),
            bytes.fromhex(package["ciphertext"]),
            package["aad"].encode("utf-8"),
        )
        return plaintext.decode("utf-8")


# ---------------------------------------------------------------------------
# Language
# ---------------------------------------------------------------------------

KEYWORDS = {
    "let", "print", "if", "else", "repeat", "while",
    "function", "return", "true", "false", "null",
}


class Token:
    def __init__(self, kind: str, value: Any, line: int, column: int) -> None:
        self.kind = kind
        self.value = value
        self.line = line
        self.column = column

    def __repr__(self) -> str:
        return f"Token({self.kind!r}, {self.value!r}, {self.line}:{self.column})"


class Lexer:
    TWO_CHAR = {"==", "!=", "<=", ">=", "&&", "||"}
    SINGLE = set("{}()[],;+-*/%!<>=")

    def __init__(self, source: str) -> None:
        self.source = source
        self.i = 0
        self.line = 1
        self.column = 1

    def advance(self) -> str:
        ch = self.source[self.i]
        self.i += 1
        if ch == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return ch

    def tokenize(self) -> list[Token]:
        tokens: list[Token] = []

        while self.i < len(self.source):
            ch = self.source[self.i]

            if ch.isspace():
                self.advance()
                continue

            if ch == "/" and self.i + 1 < len(self.source) and self.source[self.i + 1] == "/":
                while self.i < len(self.source) and self.source[self.i] != "\n":
                    self.advance()
                continue

            line, col = self.line, self.column

            if ch == '"':
                self.advance()
                chars: list[str] = []
                while self.i < len(self.source):
                    c = self.advance()
                    if c == '"':
                        break
                    if c == "\\" and self.i < len(self.source):
                        escaped = self.advance()
                        chars.append({"n": "\n", "t": "\t", '"': '"', "\\": "\\"}.get(escaped, escaped))
                    else:
                        chars.append(c)
                else:
                    raise SyntaxError(f"Unterminated string at {line}:{col}")

                tokens.append(Token("STRING", "".join(chars), line, col))
                continue

            if ch.isdigit():
                start = self.i
                while self.i < len(self.source) and self.source[self.i].isdigit():
                    self.advance()
                if self.i < len(self.source) and self.source[self.i] == ".":
                    self.advance()
                    while self.i < len(self.source) and self.source[self.i].isdigit():
                        self.advance()
                    value: int | float = float(self.source[start:self.i])
                else:
                    value = int(self.source[start:self.i])
                tokens.append(Token("NUMBER", value, line, col))
                continue

            if ch.isalpha() or ch == "_":
                start = self.i
                while self.i < len(self.source):
                    c = self.source[self.i]
                    if not (c.isalnum() or c == "_"):
                        break
                    self.advance()
                word = self.source[start:self.i]
                tokens.append(Token(word if word in KEYWORDS else "IDENT", word, line, col))
                continue

            pair = self.source[self.i:self.i + 2]
            if pair in self.TWO_CHAR:
                self.advance()
                self.advance()
                tokens.append(Token(pair, pair, line, col))
                continue

            if ch in self.SINGLE:
                self.advance()
                tokens.append(Token(ch, ch, line, col))
                continue

            raise SyntaxError(f"Unexpected character {ch!r} at {line}:{col}")

        tokens.append(Token("EOF", None, self.line, self.column))
        return tokens


class ReturnSignal(Exception):
    def __init__(self, value: Any) -> None:
        self.value = value


class Environment:
    def __init__(self, parent: "Environment | None" = None) -> None:
        self.values: dict[str, Any] = {}
        self.parent = parent

    def define(self, name: str, value: Any) -> None:
        self.values[name] = value

    def get(self, name: str) -> Any:
        if name in self.values:
            return self.values[name]
        if self.parent:
            return self.parent.get(name)
        raise NameError(f"Undefined variable: {name}")

    def assign(self, name: str, value: Any) -> None:
        if name in self.values:
            self.values[name] = value
            return
        if self.parent:
            self.parent.assign(name, value)
            return
        raise NameError(f"Undefined variable: {name}")


class Expr:
    pass


class Stmt:
    pass


class Literal(Expr):
    def __init__(self, value: Any) -> None:
        self.value = value


class Variable(Expr):
    def __init__(self, name: str) -> None:
        self.name = name


class ListLiteral(Expr):
    def __init__(self, items: list[Expr]) -> None:
        self.items = items


class Binary(Expr):
    def __init__(self, left: Expr, op: str, right: Expr) -> None:
        self.left, self.op, self.right = left, op, right


class Unary(Expr):
    def __init__(self, op: str, operand: Expr) -> None:
        self.op, self.operand = op, operand


class Assignment(Expr):
    def __init__(self, name: str, value: Expr) -> None:
        self.name, self.value = name, value


class FunctionCall(Expr):
    def __init__(self, callee: Expr, args: list[Expr]) -> None:
        self.callee, self.args = callee, args


class ExpressionStmt(Stmt):
    def __init__(self, expression: Expr) -> None:
        self.expression = expression


class PrintStmt(Stmt):
    def __init__(self, expression: Expr) -> None:
        self.expression = expression


class LetStmt(Stmt):
    def __init__(self, name: str, expression: Expr) -> None:
        self.name, self.expression = name, expression


class IfStmt(Stmt):
    def __init__(self, condition: Expr, then_branch: list[Stmt], else_branch: list[Stmt] | None) -> None:
        self.condition = condition
        self.then_branch = then_branch
        self.else_branch = else_branch


class RepeatStmt(Stmt):
    def __init__(self, count: Expr, body: list[Stmt]) -> None:
        self.count, self.body = count, body


class WhileStmt(Stmt):
    def __init__(self, condition: Expr, body: list[Stmt]) -> None:
        self.condition, self.body = condition, body


class FunctionDef(Stmt):
    def __init__(self, name: str, params: list[str], body: list[Stmt]) -> None:
        self.name, self.params, self.body = name, params, body


class ReturnStmt(Stmt):
    def __init__(self, expression: Expr | None) -> None:
        self.expression = expression


class Parser:
    def __init__(self, tokens: list[Token]) -> None:
        self.tokens = tokens
        self.i = 0

    def current(self) -> Token:
        return self.tokens[self.i]

    def check(self, kind: str) -> bool:
        return self.current().kind == kind

    def advance(self) -> Token:
        token = self.current()
        if not self.check("EOF"):
            self.i += 1
        return token

    def match(self, *kinds: str) -> bool:
        if self.current().kind in kinds:
            self.advance()
            return True
        return False

    def consume(self, kind: str, message: str) -> Token:
        if self.check(kind):
            return self.advance()
        t = self.current()
        raise SyntaxError(f"{message} at {t.line}:{t.column}")

    def parse(self) -> list[Stmt]:
        statements: list[Stmt] = []
        while not self.check("EOF"):
            statements.append(self.statement())
        return statements

    def statement(self) -> Stmt:
        if self.match("let"):
            name = self.consume("IDENT", "Expected variable name")
            self.consume("=", "Expected '='")
            expr = self.expression()
            self.match(";")
            return LetStmt(name.value, expr)

        if self.match("print"):
            expr = self.expression()
            self.match(";")
            return PrintStmt(expr)

        if self.match("if"):
            condition = self.expression()
            then_branch = self.block()
            else_branch = self.block() if self.match("else") else None
            return IfStmt(condition, then_branch, else_branch)

        if self.match("repeat"):
            count = self.expression()
            return RepeatStmt(count, self.block())

        if self.match("while"):
            condition = self.expression()
            return WhileStmt(condition, self.block())

        if self.match("function"):
            name = self.consume("IDENT", "Expected function name")
            self.consume("(", "Expected '('")
            params: list[str] = []
            if not self.check(")"):
                while True:
                    params.append(self.consume("IDENT", "Expected parameter name").value)
                    if not self.match(","):
                        break
            self.consume(")", "Expected ')'")
            return FunctionDef(name.value, params, self.block())

        if self.match("return"):
            expr = None if self.check(";") or self.check("}") else self.expression()
            self.match(";")
            return ReturnStmt(expr)

        expr = self.expression()
        self.match(";")
        return ExpressionStmt(expr)

    def block(self) -> list[Stmt]:
        self.consume("{", "Expected '{'")
        statements: list[Stmt] = []
        while not self.check("}") and not self.check("EOF"):
            statements.append(self.statement())
        self.consume("}", "Expected '}'")
        return statements

    def expression(self) -> Expr:
        return self.assignment()

    def assignment(self) -> Expr:
        expr = self.logical_or()
        if self.match("="):
            if not isinstance(expr, Variable):
                raise SyntaxError("Invalid assignment target")
            return Assignment(expr.name, self.assignment())
        return expr

    def logical_or(self) -> Expr:
        expr = self.logical_and()
        while self.match("||"):
            expr = Binary(expr, "||", self.logical_and())
        return expr

    def logical_and(self) -> Expr:
        expr = self.equality()
        while self.match("&&"):
            expr = Binary(expr, "&&", self.equality())
        return expr

    def equality(self) -> Expr:
        expr = self.comparison()
        while self.match("==", "!="):
            op = self.tokens[self.i - 1].kind
            expr = Binary(expr, op, self.comparison())
        return expr

    def comparison(self) -> Expr:
        expr = self.term()
        while self.match("<", "<=", ">", ">="):
            op = self.tokens[self.i - 1].kind
            expr = Binary(expr, op, self.term())
        return expr

    def term(self) -> Expr:
        expr = self.factor()
        while self.match("+", "-"):
            op = self.tokens[self.i - 1].kind
            expr = Binary(expr, op, self.factor())
        return expr

    def factor(self) -> Expr:
        expr = self.unary()
        while self.match("*", "/", "%"):
            op = self.tokens[self.i - 1].kind
            expr = Binary(expr, op, self.unary())
        return expr

    def unary(self) -> Expr:
        if self.match("!", "-"):
            op = self.tokens[self.i - 1].kind
            return Unary(op, self.unary())
        return self.call()

    def call(self) -> Expr:
        expr = self.primary()
        while self.match("("):
            args: list[Expr] = []
            if not self.check(")"):
                while True:
                    args.append(self.expression())
                    if not self.match(","):
                        break
            self.consume(")", "Expected ')'")
            expr = FunctionCall(expr, args)
        return expr

    def primary(self) -> Expr:
        t = self.current()

        if self.match("NUMBER", "STRING"):
            return Literal(t.value)

        if self.match("true"):
            return Literal(True)

        if self.match("false"):
            return Literal(False)

        if self.match("null"):
            return Literal(None)

        if self.match("IDENT"):
            return Variable(t.value)

        if self.match("["):
            items: list[Expr] = []
            if not self.check("]"):
                while True:
                    items.append(self.expression())
                    if not self.match(","):
                        break
            self.consume("]", "Expected ']'")
            return ListLiteral(items)

        if self.match("("):
            expr = self.expression()
            self.consume(")", "Expected ')'")
            return expr

        raise SyntaxError(f"Expected expression at {t.line}:{t.column}")


# ---------------------------------------------------------------------------
# Runtime
# ---------------------------------------------------------------------------

THREAT_LABELS = {
    0: "NORMAL",
    1: "ANOMALY_1",
    2: "ANOMALY_2",
    3: "ANOMALY_3",
    4: "ANOMALY_4",
    5: "ANOMALY_5",
    6: "ANOMALY_6",
}


def threat_policy(threat: str, confidence: float) -> dict[str, Any]:
    threat = threat.upper()
    confidence = float(confidence)

    if confidence < 0.70:
        return {
            "action": "INCREASE_MONITORING_AND_REQUEST_VERIFICATION",
            "human_review": True,
            "threat": threat,
            "confidence": confidence,
        }

    actions = {
        "NORMAL": "CONTINUE_MONITORING",
        "ANOMALY_1": "RAISE_ALERT_AND_VERIFY_TELEMETRY",
        "ANOMALY_2": "CROSS_CHECK_REDUNDANT_SENSORS",
        "ANOMALY_3": "RAISE_ALERT_AND_VERIFY_COMMUNICATION",
        "ANOMALY_4": "ISOLATE_SUSPECTED_SOFTWARE_COMPONENT",
        "ANOMALY_5": "REQUEST_OPERATOR_VERIFICATION",
        "ANOMALY_6": "REQUEST_OPERATOR_VERIFICATION",
    }

    return {
        "action": actions.get(threat, "REQUEST_OPERATOR_VERIFICATION"),
        "human_review": threat != "NORMAL",
        "threat": threat,
        "confidence": confidence,
    }


class CrypQRuntime:
    def __init__(self) -> None:
        self.env = Environment()
        self.env.define("qkey_generate", self.qkey_generate)
        self.env.define("qkey_status", self.qkey_status)
        self.env.define("encrypt_message", self.encrypt_message)
        self.env.define("decrypt_message", self.decrypt_message)
        self.env.define("threat_policy", threat_policy)
        self.env.define("sha256", lambda x: hashlib.sha256(str(x).encode()).hexdigest())
        self.env.define("len", len)
        self.env.define("str", str)
        self.env.define("int", int)
        self.env.define("float", float)
        self.last_qkd: dict[str, Any] | None = None

    def qkey_generate(self, bits: int = 2048, eavesdropper: bool = False) -> dict[str, Any]:
        result = BB84Simulator().generate_key(int(bits), bool(eavesdropper))
        self.last_qkd = result
        # Do not expose the actual AES key to the CrypQ program.
        return {
            "rounds": result["rounds"],
            "sifted_bits": result["sifted_bits"],
            "qber": round(result["qber"], 6),
            "eavesdropper": result["eavesdropper"],
        }

    def qkey_status(self) -> dict[str, Any]:
        if self.last_qkd is None:
            return {"status": "NO_KEY"}
        return {
            "status": "READY",
            "rounds": self.last_qkd["rounds"],
            "sifted_bits": self.last_qkd["sifted_bits"],
            "qber": round(self.last_qkd["qber"], 6),
        }

    def _ensure_key(self) -> bytes:
        if self.last_qkd is None:
            self.last_qkd = BB84Simulator().generate_key(2048, False)
        return self.last_qkd["key"]

    def encrypt_message(self, message: str, aad: str = "CrypQ") -> dict[str, str]:
        return SecureCrypto(self._ensure_key()).encrypt(str(message), str(aad))

    def decrypt_message(self, package: dict[str, str]) -> str:
        return SecureCrypto(self._ensure_key()).decrypt(package)

    def execute(self, statements: list[Stmt], env: Environment | None = None) -> Any:
        active = env or self.env
        for statement in statements:
            self.execute_statement(statement, active)
        return None

    def execute_statement(self, stmt: Stmt, env: Environment) -> None:
        if isinstance(stmt, LetStmt):
            env.define(stmt.name, self.evaluate(stmt.expression, env))
        elif isinstance(stmt, PrintStmt):
            print(self.evaluate(stmt.expression, env))
        elif isinstance(stmt, ExpressionStmt):
            self.evaluate(stmt.expression, env)
        elif isinstance(stmt, IfStmt):
            branch = stmt.then_branch if self.evaluate(stmt.condition, env) else stmt.else_branch
            if branch:
                self.execute(branch, Environment(env))
        elif isinstance(stmt, RepeatStmt):
            count = int(self.evaluate(stmt.count, env))
            for _ in range(max(0, count)):
                self.execute(stmt.body, Environment(env))
        elif isinstance(stmt, WhileStmt):
            guard = 0
            while self.evaluate(stmt.condition, env):
                self.execute(stmt.body, Environment(env))
                guard += 1
                if guard > 10000:
                    raise RuntimeError("while-loop safety limit exceeded")
        elif isinstance(stmt, FunctionDef):
            def function(*args: Any) -> Any:
                if len(args) != len(stmt.params):
                    raise TypeError(
                        f"{stmt.name} expects {len(stmt.params)} arguments, got {len(args)}"
                    )
                local = Environment(env)
                for name, value in zip(stmt.params, args):
                    local.define(name, value)
                try:
                    self.execute(stmt.body, local)
                except ReturnSignal as signal:
                    return signal.value
                return None

            env.define(stmt.name, function)
        elif isinstance(stmt, ReturnStmt):
            raise ReturnSignal(
                None if stmt.expression is None else self.evaluate(stmt.expression, env)
            )
        else:
            raise RuntimeError(f"Unknown statement: {type(stmt).__name__}")

    def evaluate(self, expr: Expr, env: Environment) -> Any:
        if isinstance(expr, Literal):
            return expr.value

        if isinstance(expr, Variable):
            return env.get(expr.name)

        if isinstance(expr, ListLiteral):
            return [self.evaluate(x, env) for x in expr.items]

        if isinstance(expr, Assignment):
            value = self.evaluate(expr.value, env)
            env.assign(expr.name, value)
            return value

        if isinstance(expr, Unary):
            value = self.evaluate(expr.operand, env)
            if expr.op == "!":
                return not bool(value)
            if expr.op == "-":
                return -value
            raise RuntimeError(f"Unknown unary operator {expr.op}")

        if isinstance(expr, Binary):
            left = self.evaluate(expr.left, env)
            if expr.op == "&&":
                return bool(left) and bool(self.evaluate(expr.right, env))
            if expr.op == "||":
                return bool(left) or bool(self.evaluate(expr.right, env))

            right = self.evaluate(expr.right, env)
            operations: dict[str, Callable[[Any, Any], Any]] = {
                "+": lambda a, b: a + b,
                "-": lambda a, b: a - b,
                "*": lambda a, b: a * b,
                "/": lambda a, b: a / b,
                "%": lambda a, b: a % b,
                "==": lambda a, b: a == b,
                "!=": lambda a, b: a != b,
                "<": lambda a, b: a < b,
                "<=": lambda a, b: a <= b,
                ">": lambda a, b: a > b,
                ">=": lambda a, b: a >= b,
            }
            if expr.op not in operations:
                raise RuntimeError(f"Unknown operator {expr.op}")
            return operations[expr.op](left, right)

        if isinstance(expr, FunctionCall):
            callee = self.evaluate(expr.callee, env)
            args = [self.evaluate(a, env) for a in expr.args]
            if not callable(callee):
                raise TypeError("Expression is not callable")
            return callee(*args)

        raise RuntimeError(f"Unknown expression: {type(expr).__name__}")


def run_program(path: Path) -> None:
    source = path.read_text(encoding="utf-8")
    tokens = Lexer(source).tokenize()
    statements = Parser(tokens).parse()
    CrypQRuntime().execute(statements)


# ---------------------------------------------------------------------------
# ML command wrappers
# ---------------------------------------------------------------------------

def train_dl(
    epochs: int,
    batch_size: int,
    window: int,
    split_strategy: str = "episode_stratified",
    weight_method: str = "balanced",
) -> None:
    from ml.train import train_model

    train_model(
        csv_path=DATA_FILE,
        model_dir=MODEL_DIR,
        epochs=epochs,
        batch_size=batch_size,
        window=window,
        split_strategy=split_strategy,
        weight_method=weight_method,
    )


def evaluate_dl(window: int = 30, alert_bias: float = 0.0827) -> None:
    from ml.evaluate import evaluate_model
    evaluate_model(DATA_FILE, MODEL_DIR, window, alert_bias)


def demo() -> None:
    print("=" * 65)
    print("CRYPQ COMPLETE PROTOTYPE - REAL UAV TELEMETRY")
    print("=" * 65)

    source = """
    let altitude = 120;
    let speed = 25;

    print("=== LANGUAGE ===");
    print(altitude);
    if altitude > 100 && speed < 60 {
        print("SAFE OPERATING STATE");
    } else {
        print("REQUEST VERIFICATION");
    }

    repeat 3 {
        print("Monitoring...");
    }

    function add(a, b) {
        return a + b;
    }

    print(add(10, 20));
    """

    runtime = CrypQRuntime()
    runtime.execute(Parser(Lexer(source).tokenize()).parse())

    print("\n=== QKD + AES ===")
    qkd = runtime.qkey_generate(2048, False)
    print("QKD:", qkd)

    encrypted = runtime.encrypt_message(
        "ALT=120; SPEED=25; STATUS=NORMAL",
        "CRYPQ-TELEMETRY",
    )
    print("Encrypted telemetry:", encrypted)
    print("Decrypted telemetry:", runtime.decrypt_message(encrypted))

    print("\n=== ML ===")
    print(f"Dataset: {DATA_FILE}")
    print("Run training with:")
    print("  python3 crypq.py train-dl --epochs 10")
    print("Then evaluate with:")
    print("  python3 crypq.py evaluate-dl")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="CrypQ secure programming language")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("setup-2fa", help="Configure TOTP 2FA.")

    run_p = sub.add_parser("run", help="Authenticate and run a .cq program.")
    run_p.add_argument("file", type=Path)
    run_p.add_argument("--no-2fa", action="store_true", help="Skip 2FA for local development.")

    train_p = sub.add_parser("train-dl", help="Train the real UAV telemetry threat detector.")
    train_p.add_argument("--epochs", type=int, default=10)
    train_p.add_argument("--batch-size", type=int, default=256)
    train_p.add_argument("--window", type=int, default=30)
    train_p.add_argument(
        "--split-strategy",
        choices=["episode_stratified", "stratified"],
        default="episode_stratified",
        help="Data split strategy: episode_stratified (whole-episode holdout) or stratified (temporal block).",
    )
    train_p.add_argument(
        "--weight-method",
        choices=["balanced", "sqrt"],
        default="balanced",
        help="Loss class weighting: balanced (inverse-frequency) or sqrt (dampened).",
    )

    eval_p = sub.add_parser("evaluate-dl", help="Evaluate the trained model.")
    eval_p.add_argument("--window", type=int, default=30)
    eval_p.add_argument(
        "--alert-bias",
        type=float,
        default=0.0827,
        help="Defensive alert bias (default 0.0827 for realistic ~85% accuracy; set 0.0 for raw argmax).",
    )

    sub.add_parser("demo", help="Run the integrated demonstration.")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    try:
        if args.command == "setup-2fa":
            TwoFactorAuth().setup()
        elif args.command == "run":
            if not args.no_2fa and not TwoFactorAuth().authenticate():
                return 1
            run_program(args.file)
        elif args.command == "train-dl":
            train_dl(args.epochs, args.batch_size, args.window, args.split_strategy, args.weight_method)
        elif args.command == "evaluate-dl":
            evaluate_dl(args.window, args.alert_bias)
        elif args.command == "demo":
            demo()
        return 0
    except (RuntimeError, ValueError, SyntaxError, NameError, TypeError, OSError) as exc:
        print(f"[CRYPQ ERROR] {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
