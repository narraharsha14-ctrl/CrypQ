from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

FEATURE_COLUMNS = [
    "rssi", "latency", "latitude", "longitude",
    "altitude", "battery", "packets",
]
TARGET_COLUMN = "label"
N_CLASSES = 7


def load_uav_csv(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    required = {"time", *FEATURE_COLUMNS, TARGET_COLUMN}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")

    df = df.copy()
    df["time"] = pd.to_numeric(df["time"], errors="coerce")
    for column in FEATURE_COLUMNS + [TARGET_COLUMN]:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    df = df.dropna(subset=["time", *FEATURE_COLUMNS, TARGET_COLUMN])
    df = df.sort_values("time").reset_index(drop=True)
    df[TARGET_COLUMN] = df[TARGET_COLUMN].astype(int)

    if not df[TARGET_COLUMN].between(0, N_CLASSES - 1).all():
        raise ValueError(f"Expected labels in the range 0..{N_CLASSES - 1}.")
    return df


def add_episode_ids(df: pd.DataFrame) -> pd.DataFrame:
    """Create an episode/group ID for every contiguous label run.

    Windows from one episode are kept in one split. This prevents overlapping
    windows from the same anomaly event appearing in both train and test.
    """
    out = df.copy()
    out["episode_id"] = out[TARGET_COLUMN].ne(out[TARGET_COLUMN].shift()).cumsum() - 1
    return out


def episode_stratified_split(
    df: pd.DataFrame,
    train_ratio: float = 0.70,
    val_ratio: float = 0.15,
    seed: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split complete telemetry episodes while preserving every label.

    A chronological row split is unsuitable here because anomaly episodes are
    concentrated at particular times. A random row split would leak adjacent
    windows. We therefore split contiguous label episodes as groups, with a
    deterministic per-class allocation.
    """
    if train_ratio <= 0 or val_ratio <= 0 or train_ratio + val_ratio >= 1:
        raise ValueError("train_ratio and val_ratio must be positive and sum to < 1")

    work = add_episode_ids(df)
    rng = np.random.default_rng(seed)
    train_ids: list[int] = []
    val_ids: list[int] = []
    test_ids: list[int] = []

    episode_table = (
        work.groupby("episode_id", sort=True)[TARGET_COLUMN]
        .agg(["first", "size"])
        .rename(columns={"first": "label", "size": "rows"})
    )

    for label in range(N_CLASSES):
        ids = episode_table.index[episode_table["label"] == label].to_numpy()
        ids = ids.copy()
        rng.shuffle(ids)
        n = len(ids)
        if n < 3:
            raise ValueError(
                f"Label {label} has only {n} episodes; need at least 3 for train/val/test."
            )

        # At least one complete episode in validation and test.
        n_test = max(1, int(round(n * (1 - train_ratio - val_ratio))))
        n_val = max(1, int(round(n * val_ratio)))
        if n_test + n_val >= n:
            n_test = 1
            n_val = 1

        test_ids.extend(ids[:n_test].tolist())
        val_ids.extend(ids[n_test:n_test + n_val].tolist())
        train_ids.extend(ids[n_test + n_val:].tolist())

    train = work[work["episode_id"].isin(train_ids)].sort_values("time").copy()
    val = work[work["episode_id"].isin(val_ids)].sort_values("time").copy()
    test = work[work["episode_id"].isin(test_ids)].sort_values("time").copy()

    return (
        train.reset_index(drop=True),
        val.reset_index(drop=True),
        test.reset_index(drop=True),
    )


def stratified_split(
    df: pd.DataFrame,
    train_ratio: float = 0.70,
    val_ratio: float = 0.15,
    seed: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Segment-based temporal stratified split preserving time order per block.

    Allocates initial portions of each episode to train, followed by validation
    and test segments, ensuring all anomaly classes are represented across flight
    stages while maintaining chronological integrity within each segment.
    """
    work = add_episode_ids(df)
    train_dfs, val_dfs, test_dfs = [], [], []

    for _, g in work.groupby("episode_id", sort=True):
        n = len(g)
        n_train = max(1, int(round(n * train_ratio)))
        n_val = max(1, int(round(n * val_ratio)))
        if n_train + n_val >= n:
            n_train = max(1, n - 2)
            n_val = 1
        train_dfs.append(g.iloc[:n_train])
        val_dfs.append(g.iloc[n_train:n_train + n_val])
        test_dfs.append(g.iloc[n_train + n_val:])

    return (
        pd.concat(train_dfs).reset_index(drop=True),
        pd.concat(val_dfs).reset_index(drop=True),
        pd.concat(test_dfs).reset_index(drop=True),
    )


def split_dataset(
    df: pd.DataFrame,
    strategy: str = "episode_stratified",
    train_ratio: float = 0.70,
    val_ratio: float = 0.15,
    seed: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if strategy == "stratified":
        return stratified_split(df, train_ratio, val_ratio, seed)
    return episode_stratified_split(df, train_ratio, val_ratio, seed)


def fit_scaler(train_df: pd.DataFrame) -> StandardScaler:
    scaler = StandardScaler()
    scaler.fit(train_df[FEATURE_COLUMNS].to_numpy(dtype=np.float32))
    return scaler


def make_windows(
    df: pd.DataFrame,
    scaler: StandardScaler,
    window: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Construct sliding windows strictly within contiguous episodes.

    Windows never cross episode boundaries or non-consecutive timestamp gaps,
    preventing corrupt transition states and cross-episode window leakage.
    """
    if len(df) < window:
        return (
            np.empty((0, window, len(FEATURE_COLUMNS)), dtype=np.float32),
            np.empty((0,), dtype=np.int64),
        )

    # Detect episode boundaries from episode_id or time/label discontinuities
    if "episode_id" in df.columns:
        episode_col = df["episode_id"].to_numpy()
    else:
        time_gaps = df["time"].diff().fillna(1.0).ne(1.0)
        label_changes = df[TARGET_COLUMN].ne(df[TARGET_COLUMN].shift()).fillna(True)
        episode_col = (time_gaps | label_changes).cumsum().to_numpy()

    features = scaler.transform(df[FEATURE_COLUMNS].to_numpy(dtype=np.float32)).astype(np.float32)
    labels = df[TARGET_COLUMN].to_numpy(dtype=np.int64)

    X, y = [], []
    for ep in np.unique(episode_col):
        ep_indices = np.where(episode_col == ep)[0]
        if len(ep_indices) < window:
            continue
        ep_feats = features[ep_indices]
        ep_lbls = labels[ep_indices]
        for end in range(window, len(ep_indices) + 1):
            X.append(ep_feats[end - window:end])
            y.append(int(ep_lbls[end - 1]))

    if not X:
        return (
            np.empty((0, window, len(FEATURE_COLUMNS)), dtype=np.float32),
            np.empty((0,), dtype=np.int64),
        )
    return np.stack(X), np.asarray(y, dtype=np.int64)


def class_counts(y: np.ndarray) -> dict[int, int]:
    values, counts = np.unique(y, return_counts=True)
    return {int(k): int(v) for k, v in zip(values, counts)}


def dataset_summary(df: pd.DataFrame) -> dict[str, Any]:
    counts = df[TARGET_COLUMN].value_counts().sort_index()
    return {
        "rows": len(df),
        "features": FEATURE_COLUMNS,
        "labels": {int(k): int(v) for k, v in counts.items()},
        "time_min": float(df["time"].min()),
        "time_max": float(df["time"].max()),
    }
