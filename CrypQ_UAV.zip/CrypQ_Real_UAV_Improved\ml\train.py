from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import json
from pathlib import Path

import joblib
import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from ml.model import CrypQLSTM
from ml.preprocessing import (
    FEATURE_COLUMNS, TARGET_COLUMN, N_CLASSES, class_counts,
    fit_scaler, load_uav_csv, make_windows, split_dataset,
)

LABEL_NAMES = {i: ("NORMAL" if i == 0 else f"ANOMALY_{i}") for i in range(N_CLASSES)}


def get_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def compute_class_weights(y: np.ndarray, method: str = "balanced") -> torch.Tensor:
    """Compute loss weights to counter extreme majority class dominance.

    'balanced' uses inverse frequency clipped to prevent gradient explosion,
    giving rare attack classes adequate gradient pull. 'sqrt' is dampened.
    """
    counts = np.bincount(y, minlength=N_CLASSES).astype(np.float64)
    if method == "sqrt":
        weights = np.sqrt(len(y) / (N_CLASSES * np.maximum(counts, 1.0)))
    else:
        weights = len(y) / (N_CLASSES * np.maximum(counts, 1.0))
        weights = np.clip(weights, 0.05, 50.0)
    weights /= weights.mean()
    return torch.tensor(weights, dtype=torch.float32)


def predict(model, loader, device):
    model.eval()
    true_values, predictions = [], []
    with torch.no_grad():
        for xb, yb in loader:
            pred = model(xb.to(device)).argmax(dim=1).cpu().numpy()
            predictions.extend(pred.tolist())
            true_values.extend(yb.numpy().tolist())
    return np.asarray(true_values), np.asarray(predictions)


def train_model(
    csv_path: Path,
    model_dir: Path,
    epochs: int = 20,
    batch_size: int = 256,
    window: int = 30,
    split_strategy: str = "episode_stratified",
    weight_method: str = "balanced",
) -> None:
    torch.manual_seed(42)
    np.random.seed(42)

    df = load_uav_csv(csv_path)
    train_df, val_df, test_df = split_dataset(df, strategy=split_strategy)
    scaler = fit_scaler(train_df)

    X_train, y_train = make_windows(train_df, scaler, window)
    X_val, y_val = make_windows(val_df, scaler, window)
    X_test, y_test = make_windows(test_df, scaler, window)

    if min(len(X_train), len(X_val), len(X_test)) == 0:
        raise ValueError("Not enough rows to create train/validation/test windows.")

    print("=" * 70)
    print("CRYPQ REAL UAV TELEMETRY TRAINING — EPISODE-SAFE SPLIT")
    print("=" * 70)
    print(f"Rows: {len(df):,} | Features: {len(FEATURE_COLUMNS)} | Window: {window}")
    print(f"Rows by split: train={len(train_df):,}, val={len(val_df):,}, test={len(test_df):,}")
    print(f"Windows: train={len(X_train):,}, val={len(X_val):,}, test={len(X_test):,}")
    print(f"Train labels: {class_counts(y_train)}")
    print(f"Val labels:   {class_counts(y_val)}")
    print(f"Test labels:  {class_counts(y_test)}")

    weights = compute_class_weights(y_train, method=weight_method)
    print(f"Loss weights:  {weights.numpy().round(3).tolist()}")

    train_loader = DataLoader(TensorDataset(torch.from_numpy(X_train), torch.from_numpy(y_train)), batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(TensorDataset(torch.from_numpy(X_val), torch.from_numpy(y_val)), batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(TensorDataset(torch.from_numpy(X_test), torch.from_numpy(y_test)), batch_size=batch_size, shuffle=False)

    device = get_device()
    print(f"Device: {device}")

    model = CrypQLSTM(
        input_size=len(FEATURE_COLUMNS), hidden_size=64, num_layers=2,
        num_classes=N_CLASSES, dropout=0.25,
    ).to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
    criterion = nn.CrossEntropyLoss(weight=weights.to(device), label_smoothing=0.03)

    best_f1 = -1.0
    best_state = None
    patience = 5
    stale = 0

    for epoch in range(1, epochs + 1):
        model.train()
        running_loss = 0.0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            running_loss += loss.item() * len(xb)

        val_true, val_pred = predict(model, val_loader, device)
        val_acc = accuracy_score(val_true, val_pred)
        val_f1 = f1_score(val_true, val_pred, average="macro", zero_division=0)
        print(f"Epoch {epoch:02d}/{epochs} | loss={running_loss/len(X_train):.4f} | val_acc={val_acc:.4f} | val_macro_f1={val_f1:.4f}")

        if val_f1 > best_f1 + 1e-4:
            best_f1 = val_f1
            stale = 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
            if stale >= patience:
                print(f"Early stopping after {epoch} epochs.")
                break

    if best_state is None:
        raise RuntimeError("Training did not produce a model state.")
    model.load_state_dict(best_state)

    test_true, test_pred = predict(model, test_loader, device)
    test_acc = accuracy_score(test_true, test_pred)
    test_f1 = f1_score(test_true, test_pred, average="macro", zero_division=0)

    model_dir.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), model_dir / "model.pt")
    joblib.dump(scaler, model_dir / "scaler.joblib")
    config = {
        "feature_columns": FEATURE_COLUMNS,
        "target_column": TARGET_COLUMN,
        "window": window,
        "num_classes": N_CLASSES,
        "hidden_size": 64,
        "num_layers": 2,
        "dropout": 0.25,
        "label_names": {str(k): v for k, v in LABEL_NAMES.items()},
        "split_strategy": split_strategy,
        "weight_method": weight_method,
        "test_accuracy": float(test_acc),
        "test_macro_f1": float(test_f1),
    }
    (model_dir / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    print("\n" + "=" * 70)
    print("TRAINING COMPLETE")
    print("=" * 70)
    print(f"Held-out test accuracy: {test_acc:.4f}")
    print(f"Held-out test macro F1: {test_f1:.4f}")
    print(f"Saved model: {model_dir / 'model.pt'}")
