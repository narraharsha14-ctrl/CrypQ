# CrypQ Quantum Project — Real UAV Telemetry Edition

CrypQ is a Python-interpreted experimental programming language with:
- a lexer and recursive-descent parser for `.cq` programs
- TOTP 2FA
- BB84-inspired classical QKD simulation
- AES-256-GCM authenticated encryption
- a real UAV telemetry ML pipeline
- BiLSTM + temporal attention threat classification
- evaluation with accuracy, precision, recall, macro F1, classification report and confusion matrix

## Project structure

```text
CrypQ Quantum Project/
├── crypq.py
├── requirements.txt
├── README.md
├── examples/
│   └── mission.cq
├── data/
│   └── UAV Ground Telemetry Dataset.csv
├── ml/
│   ├── __init__.py
│   ├── preprocessing.py
│   ├── model.py
│   ├── train.py
│   └── evaluate.py
└── models/
    └── crypq_lstm/
```

## Install

Use the same Python executable for installation and execution:

```bash
/usr/local/bin/python3 -m pip install -r requirements.txt
```

## Test the interpreter

```bash
/usr/local/bin/python3 crypq.py demo
```

## Run a CrypQ program without 2FA during development

```bash
/usr/local/bin/python3 crypq.py run examples/mission.cq --no-2fa
```

## Enable 2FA

```bash
/usr/local/bin/python3 crypq.py setup-2fa
```

Then:

```bash
/usr/local/bin/python3 crypq.py run examples/mission.cq
```

## Train the real UAV telemetry model

The uploaded dataset is used from:

```text
data/UAV Ground Telemetry Dataset.csv
```

Train:

```bash
/usr/local/bin/python3 crypq.py train-dl --epochs 10
```

For a longer experiment:

```bash
/usr/local/bin/python3 crypq.py train-dl --epochs 30 --batch-size 256 --window 30
```

The training pipeline:
1. Loads and validates the real CSV.
2. Sorts by `time`.
3. Uses `rssi`, `latency`, `latitude`, `longitude`, `altitude`, `battery`, and `packets` as input features.
4. Uses `label` as the target.
5. Performs a chronological 70/15/15 train/validation/test split.
6. Fits `StandardScaler` on training data only.
7. Creates 30-step temporal windows.
8. Uses class-weighted cross entropy because the dataset is strongly imbalanced.
9. Trains a two-layer bidirectional LSTM with temporal attention.
10. Selects the best model using validation macro F1.
11. Evaluates once on the held-out chronological test set.
12. Saves model/scaler/configuration.

## Evaluate

```bash
/usr/local/bin/python3 crypq.py evaluate-dl
```

## Important ML note

The CSV has seven labels (`0` through `6`). The dataset itself determines what each numeric label means. This project therefore names them `NORMAL`, `ANOMALY_1`, ..., `ANOMALY_6` rather than inventing attack names that are not explicitly established by the CSV.

If the dataset documentation provides semantic names for labels 1–6, update `LABEL_NAMES` in `ml/train.py` and `THREAT_LABELS` in `crypq.py`.

## Security limitations

- The BB84 component is a classical simulation, not physical quantum key distribution.
- Real QKD requires authenticated classical communication, error correction, privacy amplification and quantum hardware.
- The TOTP secret is stored locally for this prototype; production should use a hardware-backed secret store.
- The ML model is for defensive detection/alerting. It does not autonomously control or engage a physical platform.
- Real deployment needs signed models/code, secure boot, audit logging, adversarial ML testing, fail-safe design and independent security review.
