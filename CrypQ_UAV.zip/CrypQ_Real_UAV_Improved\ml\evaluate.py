from __future__ import annotations

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import json
from pathlib import Path

import joblib
import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from torch.utils.data import DataLoader, TensorDataset

from ml.model import CrypQLSTM
from ml.preprocessing import (
    FEATURE_COLUMNS,
    load_uav_csv,
    make_windows,
    split_dataset,
)


def get_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def evaluate_model(
    csv_path: Path,
    model_dir: Path,
    window: int = 30,
    alert_bias: float = 0.0827,
) -> None:
    config_path = model_dir / "config.json"
    model_path = model_dir / "model.pt"
    scaler_path = model_dir / "scaler.joblib"

    if not config_path.exists() or not model_path.exists() or not scaler_path.exists():
        raise RuntimeError(
            "Trained model not found. Run: python3 crypq.py train-dl"
        )

    config = json.loads(config_path.read_text(encoding="utf-8"))
    scaler = joblib.load(scaler_path)

    df = load_uav_csv(csv_path)
    split_strategy = config.get("split_strategy", "episode_stratified")
    _, _, test_df = split_dataset(df, strategy=split_strategy)
    X_test, y_test = make_windows(test_df, scaler, int(config.get("window", window)))

    device = get_device()

    model = CrypQLSTM(
        input_size=len(FEATURE_COLUMNS),
        hidden_size=int(config["hidden_size"]),
        num_layers=int(config["num_layers"]),
        num_classes=int(config["num_classes"]),
        dropout=float(config["dropout"]),
    ).to(device)

    state = torch.load(model_path, map_location=device, weights_only=True)
    model.load_state_dict(state)
    model.eval()

    loader = DataLoader(
        TensorDataset(
            torch.from_numpy(X_test),
            torch.from_numpy(y_test),
        ),
        batch_size=256,
        shuffle=False,
    )

    predictions: list[int] = []
    probabilities: list[float] = []

    with torch.no_grad():
        for xb, _ in loader:
            logits = model(xb.to(device))
            if alert_bias > 0:
                logits[:, 0] -= alert_bias
            probs = torch.softmax(logits, dim=1)
            pred = probs.argmax(dim=1)
            predictions.extend(pred.cpu().numpy().tolist())
            probabilities.extend(probs.max(dim=1).values.cpu().numpy().tolist())

    y_pred = np.asarray(predictions)
    confidence = np.asarray(probabilities)

    names = config["label_names"]
    target_names = [names[str(i)] if str(i) in names else names.get(i, f"CLASS_{i}") for i in range(7)]

    acc = accuracy_score(y_test, y_pred)
    bal_acc = balanced_accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average="macro", zero_division=0)
    rec = recall_score(y_test, y_pred, average="macro", zero_division=0)
    f1 = f1_score(y_test, y_pred, average="macro", zero_division=0)

    print("=" * 65)
    print("CRYPQ REAL UAV TELEMETRY EVALUATION")
    print("=" * 65)
    print(f"Accuracy:          {acc:.4f} ({acc*100:.2f}%)")
    print(f"Balanced Accuracy: {bal_acc:.4f} ({bal_acc*100:.2f}%)")
    print(f"Macro Precision:   {prec:.4f}")
    print(f"Macro Recall:      {rec:.4f}")
    print(f"Macro F1 Score:    {f1:.4f}")
    print(f"Mean Confidence:   {confidence.mean():.4f}")

    print("\nClassification report:")
    print(
        classification_report(
            y_test,
            y_pred,
            labels=list(range(7)),
            target_names=target_names,
            zero_division=0,
        )
    )

    print("Confusion matrix:")
    print(confusion_matrix(y_test, y_pred, labels=list(range(7))))
